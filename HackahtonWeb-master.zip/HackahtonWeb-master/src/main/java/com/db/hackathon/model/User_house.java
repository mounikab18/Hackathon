package com.db.hackathon.model;

import java.util.Date;

public class User_house {
	
	private 	int 	userId;
	private 	Date 	created;
	private 	int		electricity;
	private 	String	natural_das;
	private		String 	heating_oil;
	private		String	coal;
	private		String  propane;
	private		String	wood;
	
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	public int getElectricity() {
		return electricity;
	}
	public void setElectricity(int electricity) {
		this.electricity = electricity;
	}
	public String getNatural_das() {
		return natural_das;
	}
	public void setNatural_das(String natural_das) {
		this.natural_das = natural_das;
	}
	public String getHeating_oil() {
		return heating_oil;
	}
	public void setHeating_oil(String heating_oil) {
		this.heating_oil = heating_oil;
	}
	public String getCoal() {
		return coal;
	}
	public void setCoal(String coal) {
		this.coal = coal;
	}
	public String getPropane() {
		return propane;
	}
	public void setPropane(String propane) {
		this.propane = propane;
	}
	public String getWood() {
		return wood;
	}
	public void setWood(String wood) {
		this.wood = wood;
	}
	
	
}
