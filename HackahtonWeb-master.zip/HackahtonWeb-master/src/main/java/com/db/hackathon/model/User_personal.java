package com.db.hackathon.model;

public class User_personal {

}
