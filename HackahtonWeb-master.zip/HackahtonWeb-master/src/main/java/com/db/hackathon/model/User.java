package com.db.hackathon.model;

public class User {

	private 	int		electricity;
	private 	int		natural_das;
	private		int 	heating_oil;
	private		int		coal;
	private		int 	 propane;
	private		int		wood;
	
	private 	String	vehicle_type;
	private		int 	mileage;
	private		int		lpg;
	private		int  	water_usage;
	private		String	diet;
	
	private		String	dairy;
	private		String	fruit;
	private		String	snaks;
	
	private		String	drinks;

	public int getElectricity() {
		return electricity;
	}

	public void setElectricity(int electricity) {
		this.electricity = electricity;
	}

	public int getNatural_das() {
		return natural_das;
	}

	public void setNatural_das(int natural_das) {
		this.natural_das = natural_das;
	}

	public int getHeating_oil() {
		return heating_oil;
	}

	public void setHeating_oil(int heating_oil) {
		this.heating_oil = heating_oil;
	}

	public int getCoal() {
		return coal;
	}

	public void setCoal(int coal) {
		this.coal = coal;
	}

	public int getPropane() {
		return propane;
	}

	public void setPropane(int propane) {
		this.propane = propane;
	}

	public int getWood() {
		return wood;
	}

	public void setWood(int wood) {
		this.wood = wood;
	}

	public String getVehicle_type() {
		return vehicle_type;
	}

	public void setVehicle_type(String vehicle_type) {
		this.vehicle_type = vehicle_type;
	}

	public int getMileage() {
		return mileage;
	}

	public void setMileage(int mileage) {
		this.mileage = mileage;
	}

	public int getLpg() {
		return lpg;
	}

	public void setLpg(int lpg) {
		this.lpg = lpg;
	}

	public int getWater_usage() {
		return water_usage;
	}

	public void setWater_usage(int water_usage) {
		this.water_usage = water_usage;
	}

	public String getDiet() {
		return diet;
	}

	public void setDiet(String diet) {
		this.diet = diet;
	}

	public String getDairy() {
		return dairy;
	}

	public void setDairy(String dairy) {
		this.dairy = dairy;
	}

	public String getFruit() {
		return fruit;
	}

	public void setFruit(String fruit) {
		this.fruit = fruit;
	}

	public String getSnaks() {
		return snaks;
	}

	public void setSnaks(String snaks) {
		this.snaks = snaks;
	}

	public String getDrinks() {
		return drinks;
	}

	public void setDrinks(String drinks) {
		this.drinks = drinks;
	}
	
	
}
