package com.db.hackathon.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.db.hackathon.model.User;


@Controller
public class HackThonController {
	
	/*@Autowired
	private HackathonApplicationDAO hackathonApplicationDAO;
	
*/
   @RequestMapping("/")
   public String root() {
      return "index";
   }

   @RequestMapping("/index")
   public String index() {
      return "index";
   }
   
   @RequestMapping("/carbon")
   public String carbon() {
      return "carbon_cal";
   }
   
   @RequestMapping("/carbonCal")
   public String carbon_val(User user){
	   
	   System.out.println(user.getElectricity());
	   
	   return "carbon_sucess";
   }
   
}
